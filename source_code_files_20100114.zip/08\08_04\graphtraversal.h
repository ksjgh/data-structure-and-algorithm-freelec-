#ifndef _GRAPH_TRAVERSAL_
#define _GRAPH_TRAVERSAL_

void traversalBFS(LinkedGraph* pGraph, int startVertexID);

#endif
