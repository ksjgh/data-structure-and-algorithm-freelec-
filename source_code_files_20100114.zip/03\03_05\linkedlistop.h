#ifndef _LINKEDLIST_OP_
#define _LINKEDLIST_OP_

void iterateLinkedList(LinkedList* pList);
void concatLinkedList(LinkedList* pListA, LinkedList* pListB);
void reverseLinkedList(LinkedList* pList);

#endif