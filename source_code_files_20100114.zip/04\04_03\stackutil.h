#ifndef _STACK_UTIL_
#define _STACK_UTIL_

char* reverseString(char *pSource);
int checkBracketMatching(char *pSource);

#endif