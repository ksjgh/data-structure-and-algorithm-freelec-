#ifndef _GRAPH_TRAVERSAL_
#define _GRAPH_TRAVERSAL_

void traversalDFS(LinkedGraph* pGraph, int startVertexID);

#endif
